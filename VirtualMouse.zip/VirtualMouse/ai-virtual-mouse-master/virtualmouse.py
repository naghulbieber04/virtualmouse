import cv2
import numpy as np
import time
import pyautogui
import mediapipe as mp

# Camera size
wCam, hCam = 640, 480
frameR = 100  # Frame Reduction
smoothening = 7  # Smoothing factor

pTime = 0
plocX, plocY = 0, 0
clocX, clocY = 0, 0

cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Initialize Hand Tracking
mpHands = mp.solutions.hands
hands = mpHands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mpDraw = mp.solutions.drawing_utils

# Get screen size
wScr, hScr = pyautogui.size()

def fingersUp(hand_landmarks):
    """Checks which fingers are up."""
    fingers = [0, 0, 0, 0, 0]
    tipIds = [4, 8, 12, 16, 20]

    # Thumb (special case)
    if hand_landmarks.landmark[tipIds[0]].x < hand_landmarks.landmark[tipIds[0] - 1].x:
        fingers[0] = 1

    # Other fingers
    for i in range(1, 5):
        if hand_landmarks.landmark[tipIds[i]].y < hand_landmarks.landmark[tipIds[i] - 2].y:
            fingers[i] = 1

    return fingers

while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(imgRGB)

    if results.multi_hand_landmarks:
        for handLms in results.multi_hand_landmarks:
            lmList = []
            for id, lm in enumerate(handLms.landmark):
                cx, cy = int(lm.x * wCam), int(lm.y * hCam)
                lmList.append((id, cx, cy))

            mpDraw.draw_landmarks(img, handLms, mpHands.HAND_CONNECTIONS)

            # If landmarks detected
            if len(lmList) != 0:
                x1, y1 = lmList[8][1], lmList[8][2]  # Index Finger Tip
                x2, y2 = lmList[12][1], lmList[12][2]  # Middle Finger Tip

                fingers = fingersUp(handLms)

                # Move Mode (Only Index Finger Up)
                if fingers[1] == 1 and fingers[2] == 0:
                    x3 = np.interp(x1, (frameR, wCam-frameR), (0, wScr))
                    y3 = np.interp(y1, (frameR, hCam-frameR), (0, hScr))

                    clocX = plocX + (x3 - plocX) / smoothening
                    clocY = plocY + (y3 - plocY) / smoothening

                    pyautogui.moveTo(wScr - clocX, clocY)
                    plocX, plocY = clocX, clocY

                    cv2.circle(img, (x1, y1), 15, (255, 0, 255), cv2.FILLED)

                # Click Mode (Both Index and Middle Finger Up)
                if fingers[1] == 1 and fingers[2] == 1:
                    length = np.hypot(x2 - x1, y2 - y1)
                    if length < 40:
                        pyautogui.click()
                        cv2.circle(img, (x1, y1), 15, (0, 255, 0), cv2.FILLED)

    # FPS Display
    cTime = time.time()
    fps = 1 / (cTime - pTime)
    pTime = cTime
    cv2.putText(img, str(int(fps)), (28, 58), cv2.FONT_HERSHEY_PLAIN, 3, (255, 8, 8), 3)

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
